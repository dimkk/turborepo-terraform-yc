var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __markAsModule = (target) => __defProp(target, "__esModule", { value: true });
var __commonJS = (cb, mod) => function __require() {
  return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
};
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __reExport = (target, module2, copyDefault, desc) => {
  if (module2 && typeof module2 === "object" || typeof module2 === "function") {
    for (let key of __getOwnPropNames(module2))
      if (!__hasOwnProp.call(target, key) && (copyDefault || key !== "default"))
        __defProp(target, key, { get: () => module2[key], enumerable: !(desc = __getOwnPropDesc(module2, key)) || desc.enumerable });
  }
  return target;
};
var __toESM = (module2, isNodeMode) => {
  return __reExport(__markAsModule(__defProp(module2 != null ? __create(__getProtoOf(module2)) : {}, "default", !isNodeMode && module2 && module2.__esModule ? { get: () => module2.default, enumerable: true } : { value: module2, enumerable: true })), module2);
};
var __toCommonJS = /* @__PURE__ */ ((cache) => {
  return (module2, temp) => {
    return cache && cache.get(module2) || (temp = __reExport(__markAsModule({}), module2, 1), cache && cache.set(module2, temp), temp);
  };
})(typeof WeakMap !== "undefined" ? /* @__PURE__ */ new WeakMap() : 0);

// ../../node_modules/yandex-cloud-functions-router/dist/models/routes/httpRoute.js
var require_httpRoute = __commonJS({
  "../../node_modules/yandex-cloud-functions-router/dist/models/routes/httpRoute.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
  }
});

// ../../node_modules/yandex-cloud-functions-router/dist/models/routes/timerRoute.js
var require_timerRoute = __commonJS({
  "../../node_modules/yandex-cloud-functions-router/dist/models/routes/timerRoute.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
  }
});

// ../../node_modules/yandex-cloud-functions-router/dist/models/routes/messageQueueRoute.js
var require_messageQueueRoute = __commonJS({
  "../../node_modules/yandex-cloud-functions-router/dist/models/routes/messageQueueRoute.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
  }
});

// ../../node_modules/yandex-cloud-functions-router/dist/models/routes/objectStorageRoute.js
var require_objectStorageRoute = __commonJS({
  "../../node_modules/yandex-cloud-functions-router/dist/models/routes/objectStorageRoute.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
  }
});

// ../../node_modules/yandex-cloud-functions-router/dist/models/routes/iotMessageRoute.js
var require_iotMessageRoute = __commonJS({
  "../../node_modules/yandex-cloud-functions-router/dist/models/routes/iotMessageRoute.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
  }
});

// ../../node_modules/yandex-cloud-functions-router/dist/models/routes.js
var require_routes = __commonJS({
  "../../node_modules/yandex-cloud-functions-router/dist/models/routes.js"(exports) {
    "use strict";
    var __createBinding = exports && exports.__createBinding || (Object.create ? function(o, m, k, k2) {
      if (k2 === void 0)
        k2 = k;
      Object.defineProperty(o, k2, { enumerable: true, get: function() {
        return m[k];
      } });
    } : function(o, m, k, k2) {
      if (k2 === void 0)
        k2 = k;
      o[k2] = m[k];
    });
    var __exportStar = exports && exports.__exportStar || function(m, exports2) {
      for (var p in m)
        if (p !== "default" && !exports2.hasOwnProperty(p))
          __createBinding(exports2, m, p);
    };
    Object.defineProperty(exports, "__esModule", { value: true });
    __exportStar(require_httpRoute(), exports);
    __exportStar(require_timerRoute(), exports);
    __exportStar(require_messageQueueRoute(), exports);
    __exportStar(require_objectStorageRoute(), exports);
    __exportStar(require_iotMessageRoute(), exports);
  }
});

// ../../node_modules/yandex-cloud-functions-router/dist/models/routerOptions.js
var require_routerOptions = __commonJS({
  "../../node_modules/yandex-cloud-functions-router/dist/models/routerOptions.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
  }
});

// ../../node_modules/yandex-cloud-functions-router/dist/models/routerError.js
var require_routerError = __commonJS({
  "../../node_modules/yandex-cloud-functions-router/dist/models/routerError.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.TriggerRouteError = exports.UnknownMessageTypeRouteError = exports.UnknownEventTypeRouteError = exports.HttpParamNotSupportedTypeRouteError = exports.InvalidRequestError = exports.NoMatchedRouteError = void 0;
    var NoMatchedRouteError = class extends Error {
      constructor(message) {
        super(message);
        this.name = "ERR_NO_MATCHED_ROUTE";
        Object.setPrototypeOf(this, NoMatchedRouteError.prototype);
      }
    };
    exports.NoMatchedRouteError = NoMatchedRouteError;
    var InvalidRequestError = class extends Error {
      constructor(message) {
        super(message);
        this.name = "ERR_INVALID_REQUEST";
        Object.setPrototypeOf(this, InvalidRequestError.prototype);
      }
    };
    exports.InvalidRequestError = InvalidRequestError;
    var UnknownEventTypeRouteError = class extends Error {
      constructor(message) {
        super(message);
        this.name = "ERR_UNKNOWN_EVENT_TYPE";
        Object.setPrototypeOf(this, UnknownEventTypeRouteError.prototype);
      }
    };
    exports.UnknownEventTypeRouteError = UnknownEventTypeRouteError;
    var UnknownMessageTypeRouteError = class extends Error {
      constructor(message) {
        super(message);
        this.name = "ERR_UNKNOWN_MESSAGE_TYPE";
        Object.setPrototypeOf(this, UnknownMessageTypeRouteError.prototype);
      }
    };
    exports.UnknownMessageTypeRouteError = UnknownMessageTypeRouteError;
    var HttpParamNotSupportedTypeRouteError = class extends Error {
      constructor(message) {
        super(message);
        this.name = "ERR_PARAM_NOT_SUPPORTED_TYPE";
        Object.setPrototypeOf(this, HttpParamNotSupportedTypeRouteError.prototype);
      }
    };
    exports.HttpParamNotSupportedTypeRouteError = HttpParamNotSupportedTypeRouteError;
    var TriggerRouteError = class extends Error {
      constructor(errors) {
        super(errors.map((err) => err.toString()).join("\n"));
        this.name = "ERR_TRIGGER";
        Object.setPrototypeOf(this, TriggerRouteError.prototype);
      }
    };
    exports.TriggerRouteError = TriggerRouteError;
  }
});

// ../../node_modules/yandex-cloud-functions-router/dist/models/httpMethod.js
var require_httpMethod = __commonJS({
  "../../node_modules/yandex-cloud-functions-router/dist/models/httpMethod.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
  }
});

// ../../node_modules/yandex-cloud-functions-router/dist/models/events/httpEvent.js
var require_httpEvent = __commonJS({
  "../../node_modules/yandex-cloud-functions-router/dist/models/events/httpEvent.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
  }
});

// ../../node_modules/yandex-cloud-functions-router/dist/models/events/triggers/iotMessageTrigger.js
var require_iotMessageTrigger = __commonJS({
  "../../node_modules/yandex-cloud-functions-router/dist/models/events/triggers/iotMessageTrigger.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
  }
});

// ../../node_modules/yandex-cloud-functions-router/dist/models/events/triggers/messageQueueTrigger.js
var require_messageQueueTrigger = __commonJS({
  "../../node_modules/yandex-cloud-functions-router/dist/models/events/triggers/messageQueueTrigger.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
  }
});

// ../../node_modules/yandex-cloud-functions-router/dist/models/events/triggers/objectStorageTrigger.js
var require_objectStorageTrigger = __commonJS({
  "../../node_modules/yandex-cloud-functions-router/dist/models/events/triggers/objectStorageTrigger.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
  }
});

// ../../node_modules/yandex-cloud-functions-router/dist/models/events/triggers/timerTrigger.js
var require_timerTrigger = __commonJS({
  "../../node_modules/yandex-cloud-functions-router/dist/models/events/triggers/timerTrigger.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
  }
});

// ../../node_modules/yandex-cloud-functions-router/dist/models/events/triggers/index.js
var require_triggers = __commonJS({
  "../../node_modules/yandex-cloud-functions-router/dist/models/events/triggers/index.js"(exports) {
    "use strict";
    var __createBinding = exports && exports.__createBinding || (Object.create ? function(o, m, k, k2) {
      if (k2 === void 0)
        k2 = k;
      Object.defineProperty(o, k2, { enumerable: true, get: function() {
        return m[k];
      } });
    } : function(o, m, k, k2) {
      if (k2 === void 0)
        k2 = k;
      o[k2] = m[k];
    });
    var __exportStar = exports && exports.__exportStar || function(m, exports2) {
      for (var p in m)
        if (p !== "default" && !exports2.hasOwnProperty(p))
          __createBinding(exports2, m, p);
    };
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.isIotMessageEventMessage = exports.isObjectStorageEventMessage = exports.isMessageQueueEventMessage = exports.isTimerEventMessage = void 0;
    function isTimerEventMessage(message) {
      return message.event_metadata.event_type === "yandex.cloud.events.serverless.triggers.TimerMessage";
    }
    exports.isTimerEventMessage = isTimerEventMessage;
    function isMessageQueueEventMessage(message) {
      return message.event_metadata.event_type === "yandex.cloud.events.messagequeue.QueueMessage";
    }
    exports.isMessageQueueEventMessage = isMessageQueueEventMessage;
    function isObjectStorageEventMessage(message) {
      return message.event_metadata.event_type === "yandex.cloud.events.storage.ObjectCreate" || message.event_metadata.event_type === "yandex.cloud.events.storage.ObjectUpdate" || message.event_metadata.event_type === "yandex.cloud.events.storage.ObjectDelete";
    }
    exports.isObjectStorageEventMessage = isObjectStorageEventMessage;
    function isIotMessageEventMessage(message) {
      return message.event_metadata.event_type === "yandex.cloud.events.iot.IoTMessage";
    }
    exports.isIotMessageEventMessage = isIotMessageEventMessage;
    __exportStar(require_iotMessageTrigger(), exports);
    __exportStar(require_messageQueueTrigger(), exports);
    __exportStar(require_objectStorageTrigger(), exports);
    __exportStar(require_timerTrigger(), exports);
  }
});

// ../../node_modules/yandex-cloud-functions-router/dist/models/events/triggerEvent.js
var require_triggerEvent = __commonJS({
  "../../node_modules/yandex-cloud-functions-router/dist/models/events/triggerEvent.js"(exports) {
    "use strict";
    var __createBinding = exports && exports.__createBinding || (Object.create ? function(o, m, k, k2) {
      if (k2 === void 0)
        k2 = k;
      Object.defineProperty(o, k2, { enumerable: true, get: function() {
        return m[k];
      } });
    } : function(o, m, k, k2) {
      if (k2 === void 0)
        k2 = k;
      o[k2] = m[k];
    });
    var __exportStar = exports && exports.__exportStar || function(m, exports2) {
      for (var p in m)
        if (p !== "default" && !exports2.hasOwnProperty(p))
          __createBinding(exports2, m, p);
    };
    Object.defineProperty(exports, "__esModule", { value: true });
    __exportStar(require_triggers(), exports);
  }
});

// ../../node_modules/yandex-cloud-functions-router/dist/models/events/index.js
var require_events = __commonJS({
  "../../node_modules/yandex-cloud-functions-router/dist/models/events/index.js"(exports) {
    "use strict";
    var __createBinding = exports && exports.__createBinding || (Object.create ? function(o, m, k, k2) {
      if (k2 === void 0)
        k2 = k;
      Object.defineProperty(o, k2, { enumerable: true, get: function() {
        return m[k];
      } });
    } : function(o, m, k, k2) {
      if (k2 === void 0)
        k2 = k;
      o[k2] = m[k];
    });
    var __exportStar = exports && exports.__exportStar || function(m, exports2) {
      for (var p in m)
        if (p !== "default" && !exports2.hasOwnProperty(p))
          __createBinding(exports2, m, p);
    };
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.isTriggerEvent = exports.isHttpEvent = void 0;
    function isHttpEvent(message) {
      return Boolean(message.httpMethod);
    }
    exports.isHttpEvent = isHttpEvent;
    function isTriggerEvent(message) {
      return Boolean(message.messages);
    }
    exports.isTriggerEvent = isTriggerEvent;
    __exportStar(require_httpEvent(), exports);
    __exportStar(require_triggerEvent(), exports);
  }
});

// ../../node_modules/yandex-cloud-functions-router/dist/models/cloudFunctionEvent.js
var require_cloudFunctionEvent = __commonJS({
  "../../node_modules/yandex-cloud-functions-router/dist/models/cloudFunctionEvent.js"(exports) {
    "use strict";
    var __createBinding = exports && exports.__createBinding || (Object.create ? function(o, m, k, k2) {
      if (k2 === void 0)
        k2 = k;
      Object.defineProperty(o, k2, { enumerable: true, get: function() {
        return m[k];
      } });
    } : function(o, m, k, k2) {
      if (k2 === void 0)
        k2 = k;
      o[k2] = m[k];
    });
    var __exportStar = exports && exports.__exportStar || function(m, exports2) {
      for (var p in m)
        if (p !== "default" && !exports2.hasOwnProperty(p))
          __createBinding(exports2, m, p);
    };
    Object.defineProperty(exports, "__esModule", { value: true });
    __exportStar(require_events(), exports);
  }
});

// ../../node_modules/yandex-cloud-functions-router/dist/models/cloudFunctionContext.js
var require_cloudFunctionContext = __commonJS({
  "../../node_modules/yandex-cloud-functions-router/dist/models/cloudFunctionContext.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
  }
});

// ../../node_modules/yandex-cloud-functions-router/dist/models/cloudFunctionResult.js
var require_cloudFunctionResult = __commonJS({
  "../../node_modules/yandex-cloud-functions-router/dist/models/cloudFunctionResult.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
  }
});

// ../../node_modules/yandex-cloud-functions-router/dist/helpers/log.js
var require_log = __commonJS({
  "../../node_modules/yandex-cloud-functions-router/dist/helpers/log.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.debug = exports.log = void 0;
    var log = (level, requestId, message, params) => {
      const logger = level === "INFO" ? console.info : level === "WARN" ? console.warn : level === "ERROR" ? console.error : void 0;
      if (logger) {
        logger(`[ROUTER] ${level} RequestID: ${requestId} ${[
          message,
          ...Object.entries(params).map(([name, value]) => value !== void 0 && value !== null && value !== "" ? `${name}: ${typeof value === "object" ? JSON.stringify(value).replace(/[\r\n]+/g, "") : value}` : void 0)
        ].filter(Boolean).join(" ").trim()}`);
      }
    };
    exports.log = log;
    var debug = (requestId, message, params) => {
      if (process.env.YF_ROUTER_DEBUG) {
        console.log(`[ROUTER] DEBUG RequestID: ${requestId} ${[
          message,
          ...Object.entries(params).map(([name, value]) => value !== void 0 && value !== null && value !== "" ? `${name}: ${typeof value === "object" ? JSON.stringify(value).replace(/[\r\n]+/g, "") : value}` : void 0)
        ].filter(Boolean).join(" ").trim()}`);
      }
    };
    exports.debug = debug;
  }
});

// ../../node_modules/yandex-cloud-functions-router/dist/routers/http/getHeaderValue.js
var require_getHeaderValue = __commonJS({
  "../../node_modules/yandex-cloud-functions-router/dist/routers/http/getHeaderValue.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.getHeaderValue = void 0;
    var getHeaderValue = (request, header) => {
      if (request && header) {
        if (request.headers) {
          const headerNormalizedName = header.trim().toLowerCase();
          const [, value] = Object.entries(request.headers).find(([name]) => name.trim().toLowerCase() === headerNormalizedName) || [];
          return value;
        }
      }
      return void 0;
    };
    exports.getHeaderValue = getHeaderValue;
  }
});

// ../../node_modules/yandex-cloud-functions-router/dist/routers/http/cors/isOriginValid.js
var require_isOriginValid = __commonJS({
  "../../node_modules/yandex-cloud-functions-router/dist/routers/http/cors/isOriginValid.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.isOriginValid = void 0;
    var normalizeOrigin = (origin) => origin ? origin.trim().toLowerCase().replace(/[\\\/]+$/, "").trim() : "";
    var isOriginValid = (options, origin) => {
      if (origin) {
        if (Array.isArray(options)) {
          const allowedOrigins = options.map(normalizeOrigin);
          return allowedOrigins.indexOf(normalizeOrigin(origin)) !== -1 || allowedOrigins.indexOf("*") !== -1;
        } else if (typeof options === "object") {
          return isOriginValid(options.allowedOrigins || [], origin);
        } else if (typeof options === "string") {
          return normalizeOrigin(options) === normalizeOrigin(origin);
        }
      }
      return false;
    };
    exports.isOriginValid = isOriginValid;
  }
});

// ../../node_modules/yandex-cloud-functions-router/dist/routers/http/cors/isRequestSimple.js
var require_isRequestSimple = __commonJS({
  "../../node_modules/yandex-cloud-functions-router/dist/routers/http/cors/isRequestSimple.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.simpleRequestAllowedContentTypes = exports.simpleRequestAllowedHeaders = exports.simpleRequestAllowedMethods = exports.isRequestSimple = void 0;
    var simpleRequestAllowedMethods = ["GET", "HEAD", "POST"];
    exports.simpleRequestAllowedMethods = simpleRequestAllowedMethods;
    var simpleRequestAllowedHeaders = [
      "accept",
      "accept-language",
      "content-language",
      "content-type",
      "dpr",
      "downlink",
      "save-data",
      "viewport-width",
      "width",
      "cookie",
      "user-agent",
      "origin"
    ];
    exports.simpleRequestAllowedHeaders = simpleRequestAllowedHeaders;
    var simpleRequestAllowedContentTypes = ["application/x-www-form-urlencoded", "multipart/form-data", "text/plain"];
    exports.simpleRequestAllowedContentTypes = simpleRequestAllowedContentTypes;
    var isRequestSimple = (request) => {
      var _a;
      const isMethodValid = simpleRequestAllowedMethods.indexOf(request.httpMethod.toString().trim().toUpperCase()) !== -1;
      const areHeadersValid = Object.keys(request.headers).map((h) => h.trim().toLowerCase()).every((h) => simpleRequestAllowedHeaders.indexOf(h) !== -1);
      const [, requestContentType] = (_a = Object.entries(request.headers).find(([name]) => name.trim().toLowerCase() === "content-type")) !== null && _a !== void 0 ? _a : [];
      const isContentTypeValid = !Boolean(requestContentType) || simpleRequestAllowedContentTypes.indexOf(requestContentType) !== -1;
      return isMethodValid && areHeadersValid && isContentTypeValid;
    };
    exports.isRequestSimple = isRequestSimple;
  }
});

// ../../node_modules/yandex-cloud-functions-router/dist/routers/http/cors/isRequestMeetCorsRules.js
var require_isRequestMeetCorsRules = __commonJS({
  "../../node_modules/yandex-cloud-functions-router/dist/routers/http/cors/isRequestMeetCorsRules.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.isRequestMeetCorsRules = void 0;
    var getHeaderValue_1 = require_getHeaderValue();
    var isOriginValid_1 = require_isOriginValid();
    var isRequestSimple_1 = require_isRequestSimple();
    var isRequestMeetCorsRules = (request, options) => {
      var _a;
      const method = (_a = request.httpMethod) === null || _a === void 0 ? void 0 : _a.toString().trim().toUpperCase();
      const currentOrigin = getHeaderValue_1.getHeaderValue(request, "origin");
      const allowedHeaders = [...isRequestSimple_1.simpleRequestAllowedHeaders, ...options.allowedHeaders.map((h) => h.trim().toLowerCase())];
      const isMethodValid = options.allowedMethods.map((m) => m.trim().toUpperCase()).indexOf(method) !== -1;
      const areHeadersValid = Object.keys(request.headers).map((h) => h.trim().toLowerCase()).every((h) => allowedHeaders.indexOf(h) !== -1);
      return isMethodValid && areHeadersValid && isOriginValid_1.isOriginValid(options, currentOrigin);
    };
    exports.isRequestMeetCorsRules = isRequestMeetCorsRules;
  }
});

// ../../node_modules/yandex-cloud-functions-router/dist/routers/http/cors/appendCorsHeadersToMainResponse.js
var require_appendCorsHeadersToMainResponse = __commonJS({
  "../../node_modules/yandex-cloud-functions-router/dist/routers/http/cors/appendCorsHeadersToMainResponse.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.appendCorsHeadersToMainResponse = void 0;
    var getHeaderValue_1 = require_getHeaderValue();
    var isOriginValid_1 = require_isOriginValid();
    var isRequestMeetCorsRules_1 = require_isRequestMeetCorsRules();
    var isRequestSimple_1 = require_isRequestSimple();
    var appendCorsHeadersToMainResponse = (request, response, corsOptions) => {
      var _a;
      if (response && corsOptions.enable) {
        const currentOrigin = getHeaderValue_1.getHeaderValue(request, "origin");
        if (currentOrigin && isOriginValid_1.isOriginValid(corsOptions, currentOrigin)) {
          if (isRequestSimple_1.isRequestSimple(request) || isRequestMeetCorsRules_1.isRequestMeetCorsRules(request, corsOptions)) {
            const isCookieSet = Boolean(getHeaderValue_1.getHeaderValue(request, "cookie"));
            return Object.assign(Object.assign({}, response), { headers: Object.assign(Object.assign(Object.assign({}, (_a = response.headers) !== null && _a !== void 0 ? _a : {}), { "Access-Control-Allow-Origin": currentOrigin }), corsOptions.allowCredentials === true && isCookieSet ? { "Access-Control-Allow-Credentials": "true" } : {}) });
          }
        }
      }
      return response;
    };
    exports.appendCorsHeadersToMainResponse = appendCorsHeadersToMainResponse;
  }
});

// ../../node_modules/yandex-cloud-functions-router/dist/routers/http/cors/handleCorsPreflight.js
var require_handleCorsPreflight = __commonJS({
  "../../node_modules/yandex-cloud-functions-router/dist/routers/http/cors/handleCorsPreflight.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.handleCorsPreflight = void 0;
    var getHeaderValue_1 = require_getHeaderValue();
    var isOriginValid_1 = require_isOriginValid();
    var handleCorsPreflight = (event, options) => {
      var _a, _b, _c;
      if (event && options && options.enable) {
        const method = (_a = event.httpMethod) === null || _a === void 0 ? void 0 : _a.toString().trim().toUpperCase();
        const currentOrigin = getHeaderValue_1.getHeaderValue(event, "origin");
        if (method === "OPTIONS") {
          if (currentOrigin && isOriginValid_1.isOriginValid(options, currentOrigin)) {
            const accessControlAllowMethods = (_b = options.allowedMethods) === null || _b === void 0 ? void 0 : _b.map((m) => m.trim().toUpperCase()).join(", ");
            const accessControlAllowHeaders = (_c = options.allowedHeaders) === null || _c === void 0 ? void 0 : _c.map((m) => m.trim()).join(", ");
            const isCookieSet = Boolean(getHeaderValue_1.getHeaderValue(event, "cookie"));
            return {
              statusCode: 204,
              headers: Object.assign(Object.assign(Object.assign({ "Access-Control-Allow-Origin": currentOrigin }, accessControlAllowMethods ? { "Access-Control-Allow-Methods": accessControlAllowMethods } : {}), accessControlAllowHeaders ? { "Access-Control-Allow-Headers": accessControlAllowHeaders } : {}), options.allowCredentials === true && isCookieSet ? { "Access-Control-Allow-Credentials": "true" } : {})
            };
          } else {
            return {
              statusCode: 204
            };
          }
        }
      }
      return void 0;
    };
    exports.handleCorsPreflight = handleCorsPreflight;
  }
});

// ../../node_modules/yandex-cloud-functions-router/dist/helpers/matchObjectPattern.js
var require_matchObjectPattern = __commonJS({
  "../../node_modules/yandex-cloud-functions-router/dist/helpers/matchObjectPattern.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.matchObjectPattern = void 0;
    var matchObjectPattern = (data, pattern) => {
      var _a;
      for (const [patternPropName, patternPropValue] of Object.entries(pattern)) {
        const dataEntries = Object.entries(data);
        const [, dataPropValue] = (_a = dataEntries.find(([dataPropName, dataPropValue2]) => dataPropName === patternPropName)) !== null && _a !== void 0 ? _a : [];
        if (typeof patternPropValue === "object" || typeof dataPropValue === "object") {
          if (typeof patternPropValue === "object" && typeof dataPropValue === "object") {
            if (!matchObjectPattern(dataPropValue, patternPropValue)) {
              return false;
            }
          } else {
            return false;
          }
        } else {
          if (dataPropValue !== patternPropValue) {
            return false;
          }
        }
      }
      return true;
    };
    exports.matchObjectPattern = matchObjectPattern;
  }
});

// ../../node_modules/yandex-cloud-functions-router/dist/routers/http/cors/resolveCorsOptions.js
var require_resolveCorsOptions = __commonJS({
  "../../node_modules/yandex-cloud-functions-router/dist/routers/http/cors/resolveCorsOptions.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.resolveCorsOptions = void 0;
    var resolveCorsOptions = (options) => {
      var _a, _b, _c, _d;
      if (options) {
        if (options.enable === true) {
          return {
            enable: true,
            allowedOrigins: (_a = options.allowedOrigins) !== null && _a !== void 0 ? _a : ["*"],
            allowedMethods: (_b = options.allowedMethods) !== null && _b !== void 0 ? _b : ["GET", "HEAD", "POST"],
            allowedHeaders: (_c = options.allowedHeaders) !== null && _c !== void 0 ? _c : [],
            allowCredentials: (_d = options.allowCredentials) !== null && _d !== void 0 ? _d : true
          };
        } else {
          return { enable: false };
        }
      } else {
        return { enable: false };
      }
    };
    exports.resolveCorsOptions = resolveCorsOptions;
  }
});

// ../../node_modules/yandex-cloud-functions-router/dist/routers/httpRouter.js
var require_httpRouter = __commonJS({
  "../../node_modules/yandex-cloud-functions-router/dist/routers/httpRouter.js"(exports) {
    "use strict";
    var __awaiter = exports && exports.__awaiter || function(thisArg, _arguments, P, generator) {
      function adopt(value) {
        return value instanceof P ? value : new P(function(resolve) {
          resolve(value);
        });
      }
      return new (P || (P = Promise))(function(resolve, reject) {
        function fulfilled(value) {
          try {
            step(generator.next(value));
          } catch (e) {
            reject(e);
          }
        }
        function rejected(value) {
          try {
            step(generator["throw"](value));
          } catch (e) {
            reject(e);
          }
        }
        function step(result) {
          result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected);
        }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
      });
    };
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.httpRouter = void 0;
    var routerError_1 = require_routerError();
    var log_1 = require_log();
    var appendCorsHeadersToMainResponse_1 = require_appendCorsHeadersToMainResponse();
    var handleCorsPreflight_1 = require_handleCorsPreflight();
    var matchObjectPattern_1 = require_matchObjectPattern();
    var resolveCorsOptions_1 = require_resolveCorsOptions();
    var validateHttpMethod = (httpMethod, event) => {
      const result = httpMethod ? httpMethod.map((m) => m.trim().toLowerCase()).indexOf(event.httpMethod.trim().toLocaleLowerCase()) !== -1 : true;
      log_1.debug(event.requestContext.requestId, `Validating HTTP method: ${result ? "valid" : "invalid"}`, {
        allowed: httpMethod !== null && httpMethod !== void 0 ? httpMethod : "",
        actual: event.httpMethod
      });
      return result;
    };
    var validateParams = (params, event) => {
      if (params) {
        const eventParams = Object.entries(event.queryStringParameters).reduce((result, [key, value]) => Object.assign(Object.assign({}, result), { [key.trim().toLowerCase()]: value }), {});
        const handlerParams = Object.entries(params).reduce((result, [key, value]) => Object.assign(Object.assign({}, result), { [key.trim().toLowerCase()]: value }), {});
        log_1.debug(event.requestContext.requestId, "Validating HTTP params", { request: eventParams, route: handlerParams });
        const validationErrorFound = Object.entries(handlerParams).some(([name, { type, value, pattern }]) => {
          var _a, _b;
          const eventParamValue = eventParams[name];
          if (type === "exact") {
            log_1.debug(event.requestContext.requestId, `Validating ${name} param (type - exact): ${!(value === eventParamValue) ? "invalid" : "valid"}`, { request: eventParamValue, route: value !== null && value !== void 0 ? value : "" });
            return !(value === eventParamValue);
          } else if (type === "substring") {
            if (value) {
              log_1.debug(event.requestContext.requestId, `Validating ${name} param (type - substring): ${!(eventParamValue.indexOf(value) !== -1) ? "invalid" : "valid"}`, { request: eventParamValue, route: value !== null && value !== void 0 ? value : "" });
              return !(eventParamValue.indexOf(value) !== -1);
            } else {
              log_1.debug(event.requestContext.requestId, `Validating ${name} param (type - substring): invalid`, {
                request: eventParamValue,
                route: "(empty value)"
              });
              return true;
            }
          } else if (type === "regexp") {
            log_1.debug(event.requestContext.requestId, `Validating ${name} param (type - regexp): ${!((_a = pattern === null || pattern === void 0 ? void 0 : pattern.test(eventParamValue)) !== null && _a !== void 0 ? _a : false) ? "invalid" : "valid"}`, { request: eventParamValue, route: value !== null && value !== void 0 ? value : "" });
            return !((_b = pattern === null || pattern === void 0 ? void 0 : pattern.test(eventParamValue)) !== null && _b !== void 0 ? _b : false);
          } else {
            log_1.debug(event.requestContext.requestId, `Validating ${name} param: unknown validation type - ${type}`, {
              request: eventParamValue,
              route: value !== null && value !== void 0 ? value : ""
            });
            throw new routerError_1.HttpParamNotSupportedTypeRouteError(`Not supported type: ${type}`);
          }
        });
        return !validationErrorFound;
      } else {
        return true;
      }
    };
    var validateBodyPattern = (pattern, event) => {
      var _a;
      if (pattern) {
        log_1.debug(event.requestContext.requestId, "Validating HTTP body", { pattern });
        if (pattern.json) {
          try {
            const contentTypeMatched = String(((_a = Object.entries(event.headers).find(([name]) => name.trim().toLowerCase() === "content-type")) !== null && _a !== void 0 ? _a : [])[1] || "").toLowerCase().indexOf("application/json") !== -1;
            log_1.debug(event.requestContext.requestId, "Validating HTTP body type (JSON)", { contentTypeMatched });
            if (contentTypeMatched) {
              const bodyObject = JSON.parse(event.body);
              const result = matchObjectPattern_1.matchObjectPattern(bodyObject, pattern.json);
              log_1.debug(event.requestContext.requestId, "Validating HTTP body", { bodyObject, result });
              return result;
            } else {
              return false;
            }
          } catch (e) {
            log_1.debug(event.requestContext.requestId, "Validating HTTP body failed with error", { error: e });
            if (e instanceof SyntaxError) {
              return false;
            } else {
              throw e;
            }
          }
        } else {
          return false;
        }
      } else {
        return true;
      }
    };
    var validateWithValidators = (validators, event, context) => {
      var _a;
      try {
        return validators ? validators.every((validator) => validator(event, context)) : true;
      } catch (e) {
        log_1.log("WARN", context.requestId, `Validator failed with error: ${((_a = e === null || e === void 0 ? void 0 : e.toString()) !== null && _a !== void 0 ? _a : "unknown error").replace(/[\r\n]+/g, "")}`, {});
        return false;
      }
    };
    var unwrapBase64Body = (event) => {
      var _a;
      if (event.isBase64Encoded) {
        log_1.debug(event.requestContext.requestId, "HTTP request - unwrapping base64 body", {});
        const body = Buffer.from((_a = event.body) !== null && _a !== void 0 ? _a : "", "base64").toString("utf-8");
        return Object.assign(Object.assign({}, event), { body, isBase64Encoded: false });
      } else {
        return event;
      }
    };
    var httpRouter = (routes, event, context, options) => __awaiter(void 0, void 0, void 0, function* () {
      const corsOptions = resolveCorsOptions_1.resolveCorsOptions(options === null || options === void 0 ? void 0 : options.cors);
      log_1.debug(context.requestId, "HTTP request processing started", { CORS: corsOptions });
      for (const { httpMethod, params, body, validators, decodeBase64Body, handler: handler2 } of routes) {
        const matched = validateHttpMethod(httpMethod, event) && validateParams(params, event) && validateBodyPattern(body, event);
        log_1.debug(context.requestId, "HTTP request matching completed", {
          matched,
          event,
          httpMethod: httpMethod !== null && httpMethod !== void 0 ? httpMethod : "",
          params: params !== null && params !== void 0 ? params : "",
          body: body !== null && body !== void 0 ? body : ""
        });
        if (matched) {
          const unwrappedEvent = decodeBase64Body ? unwrapBase64Body(event) : event;
          const validatorsPassed = validateWithValidators(validators, unwrappedEvent, context);
          log_1.debug(context.requestId, "HTTP request validating completed", { validatorsPassed });
          if (validatorsPassed) {
            const handlerResult = handler2(unwrappedEvent, context);
            const result = handlerResult instanceof Promise ? yield handlerResult : handlerResult;
            log_1.debug(context.requestId, "HTTP processed", {});
            return appendCorsHeadersToMainResponse_1.appendCorsHeadersToMainResponse(event, result, corsOptions);
          } else {
            log_1.log("WARN", context.requestId, "Invalid request", {});
            throw new routerError_1.InvalidRequestError("Invalid request.");
          }
        }
      }
      const preflightResponse = handleCorsPreflight_1.handleCorsPreflight(event, corsOptions);
      if (preflightResponse) {
        log_1.debug(context.requestId, "HTTP CORS preflight request processed", { preflightResponse });
        log_1.log("INFO", context.requestId, "CORS preflight request handled ", {});
        return preflightResponse;
      } else {
        log_1.debug(context.requestId, "HTTP CORS preflight request skipped", {});
      }
      log_1.log("WARN", context.requestId, "There is no matched route", {});
      throw new routerError_1.NoMatchedRouteError("There is no matched route.");
    });
    exports.httpRouter = httpRouter;
  }
});

// ../../node_modules/yandex-cloud-functions-router/dist/routers/iotMessageRouter.js
var require_iotMessageRouter = __commonJS({
  "../../node_modules/yandex-cloud-functions-router/dist/routers/iotMessageRouter.js"(exports) {
    "use strict";
    var __awaiter = exports && exports.__awaiter || function(thisArg, _arguments, P, generator) {
      function adopt(value) {
        return value instanceof P ? value : new P(function(resolve) {
          resolve(value);
        });
      }
      return new (P || (P = Promise))(function(resolve, reject) {
        function fulfilled(value) {
          try {
            step(generator.next(value));
          } catch (e) {
            reject(e);
          }
        }
        function rejected(value) {
          try {
            step(generator["throw"](value));
          } catch (e) {
            reject(e);
          }
        }
        function step(result) {
          result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected);
        }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
      });
    };
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.iotMessageRouter = void 0;
    var log_1 = require_log();
    var routerError_1 = require_routerError();
    var validateRegistryId = (context, registryIds, message) => {
      if (registryIds) {
        const result = registryIds.some((registryId) => registryId === message.details.registry_id);
        log_1.debug(context.requestId, `Validating reugistry id: ${result ? "valid" : "invalid"}`, {
          request: message.details.registry_id,
          route: registryIds
        });
        return result;
      } else {
        return true;
      }
    };
    var validateDeviceId = (context, deviceIds, message) => {
      if (deviceIds) {
        const result = deviceIds.some((deviceId) => deviceId === message.details.device_id);
        log_1.debug(context.requestId, `Validating device id: ${result ? "valid" : "invalid"}`, {
          request: message.details.device_id,
          route: deviceIds
        });
        return result;
      } else {
        return true;
      }
    };
    var validateMqttTopic = (context, mqttTopics, message) => {
      if (mqttTopics) {
        const result = mqttTopics.some((mqttTopic) => mqttTopic === message.details.mqtt_topic);
        log_1.debug(context.requestId, `Validating MQTT topic: ${result ? "valid" : "invalid"}`, {
          request: message.details.mqtt_topic,
          route: mqttTopics
        });
        return result;
      } else {
        return true;
      }
    };
    var iotMessageRouter = (routes, event, message, context) => __awaiter(void 0, void 0, void 0, function* () {
      log_1.debug(context.requestId, "IoT Core processing started", {});
      for (const { registryId, deviceId, mqttTopic, handler: handler2 } of routes) {
        const matched = validateRegistryId(context, registryId, message) && validateDeviceId(context, deviceId, message) && validateMqttTopic(context, mqttTopic, message);
        log_1.debug(context.requestId, "IoT Core matching completed", {
          matched,
          message,
          registryId: registryId !== null && registryId !== void 0 ? registryId : "",
          deviceId: deviceId !== null && deviceId !== void 0 ? deviceId : "",
          mqttTopic: mqttTopic !== null && mqttTopic !== void 0 ? mqttTopic : ""
        });
        if (matched) {
          const result = handler2(event, context, message);
          log_1.debug(context.requestId, "IoT Core processed", {});
          return result instanceof Promise ? result : Promise.resolve(result);
        }
      }
      log_1.log("WARN", context.requestId, "There is no matched route", {});
      throw new routerError_1.NoMatchedRouteError("There is no matched route.");
    });
    exports.iotMessageRouter = iotMessageRouter;
  }
});

// ../../node_modules/yandex-cloud-functions-router/dist/routers/messageQueueRouter.js
var require_messageQueueRouter = __commonJS({
  "../../node_modules/yandex-cloud-functions-router/dist/routers/messageQueueRouter.js"(exports) {
    "use strict";
    var __awaiter = exports && exports.__awaiter || function(thisArg, _arguments, P, generator) {
      function adopt(value) {
        return value instanceof P ? value : new P(function(resolve) {
          resolve(value);
        });
      }
      return new (P || (P = Promise))(function(resolve, reject) {
        function fulfilled(value) {
          try {
            step(generator.next(value));
          } catch (e) {
            reject(e);
          }
        }
        function rejected(value) {
          try {
            step(generator["throw"](value));
          } catch (e) {
            reject(e);
          }
        }
        function step(result) {
          result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected);
        }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
      });
    };
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.messageQueueRouter = void 0;
    var routerError_1 = require_routerError();
    var log_1 = require_log();
    var matchObjectPattern_1 = require_matchObjectPattern();
    var validateQueueId = (context, queueIds, message) => {
      if (queueIds) {
        const result = queueIds.some((queueId) => message.details.queue_id === queueId);
        log_1.debug(context.requestId, `Validating queue id: ${result ? "valid" : "invalid"}`, {
          request: message.details.queue_id,
          route: queueIds
        });
        return result;
      } else {
        return true;
      }
    };
    var validateBodyJson = (context, pattern, message) => {
      if (pattern) {
        log_1.debug(context.requestId, "Validating message body json", { pattern, body: message.details.message.body });
        try {
          const bodyObject = JSON.parse(message.details.message.body);
          const result = matchObjectPattern_1.matchObjectPattern(bodyObject, pattern);
          log_1.debug(context.requestId, "Validating message body json", { bodyObject, result });
          return result;
        } catch (e) {
          log_1.debug(context.requestId, "Validating message body json failed with error", { error: e });
          if (e instanceof SyntaxError) {
            return false;
          } else {
            throw e;
          }
        }
      } else {
        return true;
      }
    };
    var validateBodyPattern = (context, pattern, message) => {
      if (pattern) {
        log_1.debug(context.requestId, "Validating message body pattern", { pattern, body: message.details.message.body });
        if (message.details.message.body) {
          const result = pattern.test(message.details.message.body);
          log_1.debug(context.requestId, "Validating message body pattern", { result });
          return result;
        } else {
          return false;
        }
      } else {
        return true;
      }
    };
    var validateWithValidators = (validators, event, context, message) => {
      var _a;
      try {
        return validators ? validators.every((validator) => validator(event, context, message)) : true;
      } catch (e) {
        log_1.log("WARN", context.requestId, `Validator failed with error: ${((_a = e === null || e === void 0 ? void 0 : e.toString()) !== null && _a !== void 0 ? _a : "unknown error").replace(/[\r\n]+/g, "")}`, {});
        return false;
      }
    };
    var messageQueueRouter = (routes, event, message, context) => __awaiter(void 0, void 0, void 0, function* () {
      log_1.debug(context.requestId, "Message queue processing started", {});
      for (const { queueId, body, validators, handler: handler2 } of routes) {
        const matched = validateQueueId(context, queueId, message) && validateBodyJson(context, body === null || body === void 0 ? void 0 : body.json, message) && validateBodyPattern(context, body === null || body === void 0 ? void 0 : body.pattern, message);
        log_1.debug(context.requestId, "Message queue matching completed", { message, matched, queueId: queueId !== null && queueId !== void 0 ? queueId : "", body: body !== null && body !== void 0 ? body : "" });
        if (matched) {
          const validatorsPassed = validateWithValidators(validators, event, context, message);
          log_1.debug(context.requestId, "Message queue validating completed", { validatorsPassed });
          if (validatorsPassed) {
            const result = handler2(event, context, message);
            log_1.debug(context.requestId, "Message queue processed", {});
            return result instanceof Promise ? result : Promise.resolve(result);
          } else {
            log_1.log("WARN", context.requestId, "Invalid request", {});
            throw new routerError_1.InvalidRequestError("Invalid request.");
          }
        }
      }
      log_1.log("WARN", context.requestId, "There is no matched route", {});
      throw new routerError_1.NoMatchedRouteError("There is no matched route.");
    });
    exports.messageQueueRouter = messageQueueRouter;
  }
});

// ../../node_modules/yandex-cloud-functions-router/dist/routers/objectStorageRouter.js
var require_objectStorageRouter = __commonJS({
  "../../node_modules/yandex-cloud-functions-router/dist/routers/objectStorageRouter.js"(exports) {
    "use strict";
    var __awaiter = exports && exports.__awaiter || function(thisArg, _arguments, P, generator) {
      function adopt(value) {
        return value instanceof P ? value : new P(function(resolve) {
          resolve(value);
        });
      }
      return new (P || (P = Promise))(function(resolve, reject) {
        function fulfilled(value) {
          try {
            step(generator.next(value));
          } catch (e) {
            reject(e);
          }
        }
        function rejected(value) {
          try {
            step(generator["throw"](value));
          } catch (e) {
            reject(e);
          }
        }
        function step(result) {
          result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected);
        }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
      });
    };
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.objectStorageRouter = void 0;
    var log_1 = require_log();
    var routerError_1 = require_routerError();
    var validateType = (context, types, message) => {
      if (types) {
        const result = types.some((type) => type === "create") && message.event_metadata.event_type === "yandex.cloud.events.storage.ObjectCreate" || types.some((type) => type === "update") && message.event_metadata.event_type === "yandex.cloud.events.storage.ObjectUpdate" || types.some((type) => type === "delete") && message.event_metadata.event_type === "yandex.cloud.events.storage.ObjectDelete";
        log_1.debug(context.requestId, `Validating type: ${result ? "valid" : "invalid"}`, {
          request: message.event_metadata.event_type,
          route: types
        });
        return result;
      } else {
        return true;
      }
    };
    var validateBucketId = (context, bucketIds, message) => {
      if (bucketIds) {
        const result = bucketIds.some((bucketId) => bucketId === message.details.bucket_id);
        log_1.debug(context.requestId, `Validating bucket id: ${result ? "valid" : "invalid"}`, {
          request: message.details.bucket_id,
          route: bucketIds
        });
        return result;
      } else {
        return true;
      }
    };
    var validateObjectId = (context, objectIds, message) => {
      if (objectIds) {
        const result = objectIds.some((objectId) => objectId === message.details.object_id);
        log_1.debug(context.requestId, `Validating object id: ${result ? "valid" : "invalid"}`, {
          request: message.details.object_id,
          route: objectIds
        });
        return result;
      } else {
        return true;
      }
    };
    var objectStorageRouter = (routes, event, message, context) => __awaiter(void 0, void 0, void 0, function* () {
      log_1.debug(context.requestId, "Object storage processing started", {});
      for (const { type, bucketId, objectId, handler: handler2 } of routes) {
        const matched = validateType(context, type, message) && validateBucketId(context, bucketId, message) && validateObjectId(context, objectId, message);
        log_1.debug(context.requestId, "Object storage matching completed", {
          matched,
          message,
          type: type !== null && type !== void 0 ? type : "",
          bucketId: bucketId !== null && bucketId !== void 0 ? bucketId : "",
          objectId: objectId !== null && objectId !== void 0 ? objectId : ""
        });
        if (matched) {
          const result = handler2(event, context, message);
          log_1.debug(context.requestId, "Object storage processed", {});
          return result instanceof Promise ? result : Promise.resolve(result);
        }
      }
      log_1.log("WARN", context.requestId, "There is no matched route", {});
      throw new routerError_1.NoMatchedRouteError("There is no matched route.");
    });
    exports.objectStorageRouter = objectStorageRouter;
  }
});

// ../../node_modules/yandex-cloud-functions-router/dist/routers/timerRouter.js
var require_timerRouter = __commonJS({
  "../../node_modules/yandex-cloud-functions-router/dist/routers/timerRouter.js"(exports) {
    "use strict";
    var __awaiter = exports && exports.__awaiter || function(thisArg, _arguments, P, generator) {
      function adopt(value) {
        return value instanceof P ? value : new P(function(resolve) {
          resolve(value);
        });
      }
      return new (P || (P = Promise))(function(resolve, reject) {
        function fulfilled(value) {
          try {
            step(generator.next(value));
          } catch (e) {
            reject(e);
          }
        }
        function rejected(value) {
          try {
            step(generator["throw"](value));
          } catch (e) {
            reject(e);
          }
        }
        function step(result) {
          result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected);
        }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
      });
    };
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.timerRouter = void 0;
    var log_1 = require_log();
    var routerError_1 = require_routerError();
    var validateTriggerId = (context, triggerIds, message) => {
      if (triggerIds) {
        const result = triggerIds.some((triggerId) => message.details.trigger_id === triggerId);
        log_1.debug(context.requestId, `Validating trigger id: ${result ? "valid" : "invalid"}`, {
          request: message.details.trigger_id,
          route: triggerIds
        });
        return result;
      } else {
        return true;
      }
    };
    var timerRouter = (routes, event, message, context) => __awaiter(void 0, void 0, void 0, function* () {
      log_1.debug(context.requestId, "Timer processing started", {});
      for (const { handler: handler2, triggerId } of routes) {
        const matched = validateTriggerId(context, triggerId, message);
        log_1.debug(context.requestId, "Timer matching completed", { message, matched, triggerId: triggerId !== null && triggerId !== void 0 ? triggerId : "" });
        if (matched) {
          const result = handler2(event, context, message);
          if (result instanceof Promise) {
            log_1.debug(context.requestId, "Timer processed", {});
            return result;
          } else {
            log_1.debug(context.requestId, "Timer processed", {});
            return Promise.resolve(result);
          }
        }
      }
      log_1.log("WARN", context.requestId, "There is no matched route", {});
      throw new routerError_1.NoMatchedRouteError("There is no matched route.");
    });
    exports.timerRouter = timerRouter;
  }
});

// ../../node_modules/yandex-cloud-functions-router/dist/router.js
var require_router = __commonJS({
  "../../node_modules/yandex-cloud-functions-router/dist/router.js"(exports) {
    "use strict";
    var __awaiter = exports && exports.__awaiter || function(thisArg, _arguments, P, generator) {
      function adopt(value) {
        return value instanceof P ? value : new P(function(resolve) {
          resolve(value);
        });
      }
      return new (P || (P = Promise))(function(resolve, reject) {
        function fulfilled(value) {
          try {
            step(generator.next(value));
          } catch (e) {
            reject(e);
          }
        }
        function rejected(value) {
          try {
            step(generator["throw"](value));
          } catch (e) {
            reject(e);
          }
        }
        function step(result) {
          result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected);
        }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
      });
    };
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.router = void 0;
    var cloudFunctionEvent_1 = require_cloudFunctionEvent();
    var routerError_1 = require_routerError();
    var httpRouter_1 = require_httpRouter();
    var iotMessageRouter_1 = require_iotMessageRouter();
    var log_1 = require_log();
    var messageQueueRouter_1 = require_messageQueueRouter();
    var objectStorageRouter_1 = require_objectStorageRouter();
    var timerRouter_1 = require_timerRouter();
    var router2 = (routes, options) => (event, context) => __awaiter(void 0, void 0, void 0, function* () {
      var _a;
      try {
        if (cloudFunctionEvent_1.isHttpEvent(event)) {
          log_1.log("INFO", context.requestId, "", {
            "HTTP Method": event.httpMethod,
            "Body Length": event.body.length,
            Query: event.queryStringParameters,
            Headers: event.headers
          });
          return yield httpRouter_1.httpRouter(routes.http || [], event, context, options);
        } else if (cloudFunctionEvent_1.isTriggerEvent(event)) {
          const errors = [];
          for (const message of event.messages) {
            try {
              if (cloudFunctionEvent_1.isTimerEventMessage(message)) {
                log_1.log("INFO", context.requestId, "Processing timer trigger message", {
                  "Trigger Id": message.details.trigger_id
                });
                yield timerRouter_1.timerRouter(routes.timer || [], event, message, context);
              } else if (cloudFunctionEvent_1.isMessageQueueEventMessage(message)) {
                log_1.log("INFO", context.requestId, "Processing message queue message", {
                  "Queue Id": message.details.queue_id
                });
                yield messageQueueRouter_1.messageQueueRouter(routes.message_queue || [], event, message, context);
              } else if (cloudFunctionEvent_1.isObjectStorageEventMessage(message)) {
                log_1.log("INFO", context.requestId, "Processing object storage message", {
                  "Bucket Id": message.details.bucket_id,
                  "Object Id": message.details.object_id
                });
                yield objectStorageRouter_1.objectStorageRouter(routes.object_storage || [], event, message, context);
              } else if (cloudFunctionEvent_1.isIotMessageEventMessage(message)) {
                log_1.log("INFO", context.requestId, "Processing IoT Core message", {
                  "Registry Id": message.details.registry_id,
                  "Device Id": message.details.device_id,
                  "MQTT Topic": message.details.mqtt_topic
                });
                yield iotMessageRouter_1.iotMessageRouter(routes.iot_message || [], event, message, context);
              } else {
                log_1.log("ERROR", context.requestId, "Unknown message type", {});
                throw new routerError_1.UnknownMessageTypeRouteError("Unknown message type.");
              }
            } catch (e) {
              log_1.log("ERROR", context.requestId, "Unexcpected error during message processing", {
                Error: e
              });
              errors.push(e);
            }
          }
          if (errors.length === 1) {
            throw errors[0];
          } else if (errors.length > 1) {
            throw new routerError_1.TriggerRouteError(errors);
          } else {
            return {
              statusCode: 200
            };
          }
        } else {
          log_1.log("ERROR", context.requestId, "Unknown event type", {});
          throw new routerError_1.UnknownEventTypeRouteError("Unknown event type.");
        }
      } catch (error) {
        const errorHandling = (_a = options === null || options === void 0 ? void 0 : options.errorHandling) !== null && _a !== void 0 ? _a : {
          notFound: () => ({
            statusCode: 404
          }),
          invalidRequest: () => ({
            statusCode: 400
          }),
          unknownEvent: () => ({
            statusCode: 404
          }),
          unknownMessage: () => ({
            statusCode: 404
          })
        };
        if (errorHandling) {
          if (error instanceof routerError_1.NoMatchedRouteError && errorHandling.notFound) {
            return errorHandling.notFound(error);
          } else if (error instanceof routerError_1.InvalidRequestError && errorHandling.invalidRequest) {
            return errorHandling.invalidRequest(error);
          } else if (error instanceof routerError_1.UnknownEventTypeRouteError && errorHandling.unknownEvent) {
            return errorHandling.unknownEvent(error);
          } else if (error instanceof routerError_1.UnknownMessageTypeRouteError && errorHandling.unknownMessage) {
            return errorHandling.unknownMessage(error);
          } else if (error instanceof routerError_1.TriggerRouteError && errorHandling.triggerCombinedError) {
            return errorHandling.triggerCombinedError(error);
          } else if (errorHandling.custom) {
            for (const customErrorHandler of errorHandling.custom) {
              if (customErrorHandler.error && customErrorHandler.result) {
                if (typeof customErrorHandler.error === "string" && error.message === customErrorHandler.error) {
                  return customErrorHandler.result(error);
                } else if (customErrorHandler.error instanceof RegExp && customErrorHandler.error.test(error.message)) {
                  return customErrorHandler.result(error);
                }
              }
            }
          }
        }
        throw error;
      }
    });
    exports.router = router2;
  }
});

// ../../node_modules/yandex-cloud-functions-router/dist/index.js
var require_dist = __commonJS({
  "../../node_modules/yandex-cloud-functions-router/dist/index.js"(exports) {
    "use strict";
    var __createBinding = exports && exports.__createBinding || (Object.create ? function(o, m, k, k2) {
      if (k2 === void 0)
        k2 = k;
      Object.defineProperty(o, k2, { enumerable: true, get: function() {
        return m[k];
      } });
    } : function(o, m, k, k2) {
      if (k2 === void 0)
        k2 = k;
      o[k2] = m[k];
    });
    var __exportStar = exports && exports.__exportStar || function(m, exports2) {
      for (var p in m)
        if (p !== "default" && !exports2.hasOwnProperty(p))
          __createBinding(exports2, m, p);
    };
    Object.defineProperty(exports, "__esModule", { value: true });
    __exportStar(require_routes(), exports);
    __exportStar(require_routerOptions(), exports);
    __exportStar(require_routerError(), exports);
    __exportStar(require_httpMethod(), exports);
    __exportStar(require_cloudFunctionEvent(), exports);
    __exportStar(require_cloudFunctionContext(), exports);
    __exportStar(require_cloudFunctionResult(), exports);
    __exportStar(require_httpRoute(), exports);
    __exportStar(require_events(), exports);
    __exportStar(require_router(), exports);
  }
});

// src/index.ts
var src_exports = {};
__export(src_exports, {
  handler: () => handler
});
var import_yandex_cloud_functions_router = __toESM(require_dist());
var handler = (0, import_yandex_cloud_functions_router.router)({
  http: [
    {
      httpMethod: ["GET"],
      params: {
        type: {
          type: "exact",
          value: "add"
        }
      },
      handler: (event, context) => {
        console.log({ event, context });
        return {
          statusCode: 200
        };
      }
    },
    {
      httpMethod: ["GET"],
      params: {
        type: {
          type: "substring",
          value: "upd"
        }
      },
      handler: (event, context) => {
        console.log({ event, context });
        return {
          statusCode: 200
        };
      }
    },
    {
      httpMethod: ["GET"],
      params: {
        type: {
          type: "regexp",
          pattern: /x[0-9]+/i
        }
      },
      handler: (event, context) => {
        console.log({ event, context });
        return {
          statusCode: 200
        };
      }
    },
    {
      httpMethod: ["POST"],
      body: {
        json: {
          type: "add"
        }
      },
      handler: (event, context) => {
        console.log({ event, context });
        return {
          statusCode: 200
        };
      }
    },
    {
      httpMethod: ["GET", "POST"],
      handler: (event, context) => {
        console.log({ event, context });
        return {
          statusCode: 200
        };
      }
    }
  ],
  timer: [
    {
      triggerId: ["a4wt2lnqwvjwnregbqbb"],
      handler: (event, context, message) => {
        console.log({ event, context });
        return {
          statusCode: 200
        };
      }
    },
    {
      handler: (event, context, message) => {
        console.log({ event, context });
        return {
          statusCode: 200
        };
      }
    }
  ],
  message_queue: [
    {
      queueId: ["a4wt2lnqwvjwnregbqbb"],
      body: {
        json: {
          type: "add"
        }
      },
      handler: (event, context, message) => {
        console.log({ event, context, message });
        return {
          statusCode: 200
        };
      }
    },
    {
      queueId: ["a4wt2lnqwvjwnregbqbb"],
      body: {
        pattern: /test/i
      },
      handler: (event, context, message) => {
        console.log({ event, context, message });
        return {
          statusCode: 200
        };
      }
    },
    {
      handler: (event, context, message) => {
        console.log({ event, context, message });
        return {
          statusCode: 200
        };
      }
    }
  ],
  object_storage: [
    {
      type: ["create"],
      bucketId: ["s3"],
      handler: (event, context, message) => {
        console.log({ event, context, message });
        return {
          statusCode: 200
        };
      }
    },
    {
      bucketId: ["s3"],
      handler: (event, context, message) => {
        console.log({ event, context, message });
        return {
          statusCode: 200
        };
      }
    },
    {
      objectId: ["1.jpg"],
      handler: (event, context, message) => {
        console.log({ event, context, message });
        return {
          statusCode: 200
        };
      }
    },
    {
      handler: (event, context, message) => {
        console.log({ event, context, message });
        return {
          statusCode: 200
        };
      }
    }
  ],
  iot_message: [
    {
      registryId: ["arenou2oj4ct42eq8g3n"],
      deviceId: ["areqjd6un3afc3cefcvm"],
      handler: (event, context, message) => {
        console.log({ event, context, message });
        return {
          statusCode: 200
        };
      }
    },
    {
      registryId: ["arenou2oj4ct42eq8g3n"],
      handler: (event, context, message) => {
        console.log({ event, context, message });
        return {
          statusCode: 200
        };
      }
    },
    {
      deviceId: ["areqjd6un3afc3cefcvm"],
      handler: (event, context, message) => {
        console.log({ event, context, message });
        return {
          statusCode: 200
        };
      }
    },
    {
      mqttTopic: ["$devices/areqjd6un3afc3cefcvm/events"],
      handler: (event, context, message) => {
        console.log({ event, context, message });
        return {
          statusCode: 200
        };
      }
    },
    {
      mqttTopic: ["$devices/areqjd6un3afc3cefcvm/events"],
      handler: (event, context, message) => {
        console.log({ event, context, message });
        return {
          statusCode: 200
        };
      }
    }
  ]
});
module.exports = __toCommonJS(src_exports);
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
